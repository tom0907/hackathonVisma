create function "overlaps"(time without time zone, interval, time without time zone, time without time zone) returns boolean
    immutable
    parallel safe
    cost 1
    language internal
as
$$
begin
-- missing source code
end;
$$;

comment on function "overlaps"(timestamp with time zone, timestamp with time zone, timestamp with time zone, timestamp with time zone) is 'intervals overlap?';

alter function "overlaps"(timestamp with time zone, timestamp with time zone, timestamp with time zone, timestamp with time zone) owner to postgres;

