create function "overlaps"(time without time zone, time without time zone, time without time zone, interval) returns boolean
    immutable
    parallel safe
    cost 1
    language internal
as
$$
begin
-- missing source code
end;
$$;

comment on function "overlaps"(time, time, time, time) is 'intervals overlap?';

alter function "overlaps"(time, time, time, time) owner to postgres;

