create function trunc(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$
begin
-- missing source code
end;
$$;

comment on function trunc(macaddr8) is 'MACADDR8 manufacturer fields';

alter function trunc(macaddr8) owner to postgres;

